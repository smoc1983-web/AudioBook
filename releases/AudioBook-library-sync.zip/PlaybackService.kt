package com.audiobookdownloader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

data class ServiceTrack(val title: String, val src: String, val durationMs: Int = 0)

data class ServicePlaybackState(
    val bookTitle: String = "",
    val sourceType: String = "local",
    val tracks: List<ServiceTrack> = emptyList(),
    val trackIndex: Int = -1,
    val positionMs: Int = 0,
    val durationMs: Int = 0,
    val isPlaying: Boolean = false,
    val isLoading: Boolean = false,
    val hasPlayer: Boolean = false,
    val speed: Float = 1f,
    val eqAvailable: Boolean = true,
    val sleepSeconds: Int = 0,
    val sleepChapterTarget: String = "",
    val error: String = ""
)

/** Экран хранит только команды и снимок состояния, а не MediaPlayer. */
class PlaybackControl(context: Context, private val sourceType: String) {
    private val appContext = context.applicationContext
    private val state get() = PlaybackService.state.value
    val currentPosition get() = state.positionMs
    val duration get() = state.durationMs
    val isPlaying get() = state.sourceType == sourceType && state.isPlaying
    fun start() = PlaybackService.command(appContext, PlaybackService.ACTION_PLAY, sourceType)
    fun pause() = PlaybackService.command(appContext, PlaybackService.ACTION_PAUSE, sourceType)
    fun seekTo(position: Int) = PlaybackService.seek(appContext, position.toLong(), sourceType)
    fun stop() = PlaybackService.command(appContext, PlaybackService.ACTION_STOP, sourceType)
}

class PlaybackService : Service() {
    companion object {
        private const val CHANNEL_ID = "audiobook_playback"
        private const val NOTIFICATION_ID = 7001
        const val ACTION_TOGGLE = "com.audiobookdownloader.TOGGLE"
        const val ACTION_PREVIOUS = "com.audiobookdownloader.PREVIOUS"
        const val ACTION_NEXT = "com.audiobookdownloader.NEXT"
        const val ACTION_REWIND = "com.audiobookdownloader.REWIND_30"
        const val ACTION_FORWARD = "com.audiobookdownloader.FORWARD_30"
        const val ACTION_STOP = "com.audiobookdownloader.STOP"
        const val ACTION_PLAY = "com.audiobookdownloader.PLAY"
        const val ACTION_PAUSE = "com.audiobookdownloader.PAUSE"
        private const val ACTION_START = "com.audiobookdownloader.START_PLAYLIST"
        private const val ACTION_SEEK = "com.audiobookdownloader.SEEK"
        private const val ACTION_SLEEP = "com.audiobookdownloader.SLEEP"
        private const val ACTION_SETTINGS = "com.audiobookdownloader.SETTINGS"
        private const val EXTRA_SOURCE = "source_type"
        private const val EXTRA_POSITION = "position_long"
        private const val EXTRA_REQUEST = "request_file"
        private val mutableState = MutableStateFlow(ServicePlaybackState())
        val state: StateFlow<ServicePlaybackState> = mutableState.asStateFlow()
        @Volatile private var instance: PlaybackService? = null

        private fun send(context: Context, intent: Intent) {
            val running = instance
            if (running != null && !running.stopped && Looper.myLooper() == Looper.getMainLooper()) {
                running.handleCommand(intent)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.applicationContext.startForegroundService(intent)
            } else {
                context.applicationContext.startService(intent)
            }
        }

        fun command(context: Context, action: String, sourceType: String? = null) {
            send(context, Intent(context, PlaybackService::class.java).apply {
                this.action = action
                if (sourceType != null) putExtra(EXTRA_SOURCE, sourceType)
            })
        }

        fun play(
            context: Context, bookTitle: String, sourceType: String,
            tracks: List<ServiceTrack>, index: Int, positionMs: Int = 0
        ) {
            if (tracks.isEmpty() || index !in tracks.indices) return
            val playlist = JSONArray()
            tracks.forEach { playlist.put(JSONObject().put("t", it.title)
                .put("s", it.src).put("d", it.durationMs)) }
            val request = JSONObject().put("book", bookTitle).put("source", sourceType)
                .put("tracks", playlist).put("index", index).put("position", positionMs)
            // Большой плейлист не передаётся через Binder (лимит размера Intent).
            val file = File.createTempFile("playback-request-", ".json", context.cacheDir)
            try {
                file.writeText(request.toString(), Charsets.UTF_8)
                send(context, Intent(context, PlaybackService::class.java).apply {
                    action = ACTION_START
                    putExtra(EXTRA_REQUEST, file.name)
                })
            } catch (error: Exception) {
                file.delete()
                throw error
            }
        }

        fun seek(context: Context, positionMs: Long, sourceType: String? = null) {
            send(context, Intent(context, PlaybackService::class.java).apply {
                action = ACTION_SEEK
                putExtra(EXTRA_POSITION, positionMs)
                if (sourceType != null) putExtra(EXTRA_SOURCE, sourceType)
            })
        }

        fun selectChapter(context: Context, index: Int, positionMs: Int = 0) {
            val current = state.value
            if (index !in current.tracks.indices) return
            play(context, current.bookTitle, current.sourceType, current.tracks, index, positionMs)
        }

        fun setSleepTimer(context: Context, seconds: Int, chapter: Boolean = false) {
            send(context, Intent(context, PlaybackService::class.java).apply {
                action = ACTION_SLEEP
                putExtra("seconds", seconds)
                putExtra("chapter", chapter)
            })
        }

        fun refreshSettings(context: Context) {
            if (instance != null) command(context, ACTION_SETTINGS)
        }

        fun stop(context: Context) {
            if (instance != null) command(context, ACTION_STOP)
        }
    }

    private lateinit var mediaSession: MediaSession
    private val handler = Handler(Looper.getMainLooper())
    private val queueWorker = Executors.newSingleThreadExecutor()
    private val playbackPrefs by lazy {
        getSharedPreferences("audiobook_downloader", Context.MODE_PRIVATE)
    }
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val sensorManager by lazy { getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    private val audioFx = AudioFx()
    private var mediaPlayer: MediaPlayer? = null
    private var playlist: List<ServiceTrack> = emptyList()
    private var sourceType = "local"
    private var trackIndex = -1
    private var bookTitle = "Аудиокнига"
    private var trackTitle = "Глава"
    private var positionMs = 0
    private var durationMs = 0
    private var isPlaying = false
    private var isLoading = false
    private var playWhenReady = true
    private var generation = 0L
    private var stopped = false
    private var errorMessage = ""
    private var playbackSpeed = 1f
    private var eqAvailable = true
    private var appliedEq: EqSettings? = null
    private var hasAudioFocus = false
    private var resumeAfterFocus = false
    private var duckVolume = 1f
    private var pausedAt = 0L
    private var pendingSeek: Int? = null
    private var sleepEndAt = 0L
    private var sleepChapterTarget = ""
    private var shakeRegistered = false
    private var lastShakeAt = 0L
    private var shakeWindowStart = 0L
    private var strongShakeHits = 0
    private var lastPersistAt = 0L
    private var lastNotificationAt = 0L
    private var coverBook = ""
    private var coverBitmap: Bitmap? = null
    private var metadataKey = ""

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        handler.post {
            if (!stopped) when (change) {
                AudioManager.AUDIOFOCUS_GAIN -> {
                    hasAudioFocus = true
                    duckVolume = 1f
                    if (resumeAfterFocus) {
                        resumeAfterFocus = false
                        resumePlayback()
                    }
                    updateVolume()
                }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                    resumeAfterFocus = isPlaying || (isLoading && playWhenReady)
                    hasAudioFocus = false
                    pausePlayback(releaseFocus = false)
                }
                AudioManager.AUDIOFOCUS_LOSS -> {
                    resumeAfterFocus = false
                    hasAudioFocus = false
                    pausePlayback()
                }
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                    duckVolume = 0.2f
                    updateVolume()
                }
            }
        }
    }

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                resumeAfterFocus = false
                pausePlayback()
            }
        }
    }

    private val preferenceListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "playback_speed" || key == "book_speed_" + safeFileName(bookTitle) ||
            key == EQ_GLOBAL_KEY || key == eqBookKey(bookTitle) || key == "sleep_shake") {
            handler.post { if (!stopped) { applySettings(); publish() } }
        }
    }

    private val shakeListener = object : SensorEventListener {
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        override fun onSensorChanged(event: SensorEvent?) {
            if (event == null || !isPlaying || !timerActive()) return
            val x = event.values[0] / SensorManager.GRAVITY_EARTH
            val y = event.values[1] / SensorManager.GRAVITY_EARTH
            val z = event.values[2] / SensorManager.GRAVITY_EARTH
            val now = SystemClock.elapsedRealtime()
            if (x * x + y * y + z * z < 5.76f) return
            if (now - shakeWindowStart > 1200L) {
                shakeWindowStart = now
                strongShakeHits = 0
            }
            strongShakeHits++
            if (strongShakeHits >= 3 && now - lastShakeAt > 3000L) {
                lastShakeAt = now
                strongShakeHits = 0
                if (sleepChapterTarget.isEmpty()) {
                    setTimer(playbackPrefs.getInt("last_sleep_seconds", 1800).coerceAtLeast(60), false)
                }
                Toast.makeText(this@PlaybackService, "🌙 Таймер сна продлён", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (stopped) return
            readPosition()
            val now = SystemClock.elapsedRealtime()
            if (sleepEndAt > 0L && now >= sleepEndAt) {
                setTimer(0, false)
                resumeAfterFocus = false
                pausePlayback()
                Toast.makeText(this@PlaybackService, "🌙 Таймер сна: воспроизведение остановлено",
                    Toast.LENGTH_LONG).show()
            }
            updateVolume()
            updateShakeListener()
            if (isPlaying && now - lastPersistAt >= 5000L) persistState()
            publish(refreshNotification = now - lastNotificationAt >= 1000L)
            handler.postDelayed(this, 500L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        mediaSession = MediaSession(this, "AudioBookDownloaderSession")
        mediaSession.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { resumeAfterFocus = false; resumePlayback() }
            override fun onPause() { resumeAfterFocus = false; pausePlayback() }
            override fun onSkipToPrevious() { skip(-1) }
            override fun onSkipToNext() { skip(1) }
            override fun onStop() { stopPlayback() }
            override fun onSeekTo(pos: Long) { seekPlayback(pos) }
        }, handler)
        mediaSession.isActive = true
        restorePlaylist()
        playbackPrefs.registerOnSharedPreferenceChangeListener(preferenceListener)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(noisyReceiver, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
                Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(noisyReceiver, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        }
        handler.post(tickRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (stopped) {
            stopped = false
            instance = this
            handler.removeCallbacks(tickRunnable)
            handler.post(tickRunnable)
        }
        // Уведомление создаётся до prepareAsync и до запроса аудиофокуса.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
        if (intent != null) handleCommand(intent)
        else { publish(); stopPlayback() }
        return START_NOT_STICKY
    }

    private fun handleCommand(intent: Intent) {
        if (stopped) return
        val requestedSource = intent.getStringExtra(EXTRA_SOURCE)
        if (requestedSource != null && requestedSource != sourceType) return
        when (intent.action) {
            ACTION_START -> acceptRequest(intent.getStringExtra(EXTRA_REQUEST))
            ACTION_TOGGLE -> {
                resumeAfterFocus = false
                if (isPlaying || (isLoading && playWhenReady)) pausePlayback() else resumePlayback()
            }
            ACTION_PLAY -> { resumeAfterFocus = false; resumePlayback() }
            ACTION_PAUSE -> { resumeAfterFocus = false; pausePlayback() }
            ACTION_PREVIOUS -> skip(-1)
            ACTION_NEXT -> skip(1)
            ACTION_REWIND -> { readPosition(); seekPlayback(positionMs.toLong() - 30_000L) }
            ACTION_FORWARD -> { readPosition(); seekPlayback(positionMs.toLong() + 30_000L) }
            ACTION_SEEK -> seekPlayback(intent.getLongExtra(EXTRA_POSITION, 0L))
            ACTION_STOP -> stopPlayback()
            ACTION_SLEEP -> setTimer(intent.getIntExtra("seconds", 0), intent.getBooleanExtra("chapter", false))
            ACTION_SETTINGS -> { applySettings(); publish() }
        }
    }

    private fun parseTracks(array: JSONArray): List<ServiceTrack> =
        (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val src = item.optString("s")
            if (src.isBlank()) null else ServiceTrack(item.optString("t"), src, item.optInt("d", 0))
        }

    private fun acceptRequest(name: String?) {
        if (name == null || !name.startsWith("playback-request-") || File(name).name != name) return
        val file = File(cacheDir, name)
        try {
            val request = JSONObject(file.readText(Charsets.UTF_8))
            val requestedTracks = request.getJSONArray("tracks")
            val tracks = parseTracks(requestedTracks)
            require(tracks.size == requestedTracks.length()) { "У главы отсутствует адрес аудио" }
            val index = request.getInt("index")
            require(index in tracks.indices) { "Пустой плейлист или неверный номер главы" }
            readPosition()
            persistState()
            releasePlayer()
            generation++
            playlist = tracks
            bookTitle = request.getString("book").ifBlank { "Аудиокнига" }
            sourceType = if (request.optString("source") == "online") "online" else "local"
            persistPlaylist()
            addListeningHistory(playbackPrefs, bookTitle)
            startTrack(index, request.optInt("position", 0))
        } catch (error: Exception) {
            failPlayback("Не удалось запустить главу: ${error.message ?: "ошибка плеера"}")
        } finally {
            file.delete()
        }
    }

    private fun restorePlaylist() {
        try {
            playlist = parseTracks(JSONArray(playbackPrefs.getString("widget_playlist", "[]") ?: "[]"))
            if (playlist.isEmpty()) {
                val src = playbackPrefs.getString("widget_media_src", "").orEmpty()
                if (src.isNotBlank()) playlist = listOf(ServiceTrack(
                    playbackPrefs.getString("widget_track", "Глава").orEmpty(), src))
            }
            sourceType = playbackPrefs.getString("widget_source_type", "local") ?: "local"
            bookTitle = playbackPrefs.getString("widget_book", "Аудиокнига").orEmpty()
            trackIndex = playbackPrefs.getInt("widget_track_index", 0)
                .coerceIn(0, playlist.lastIndex.coerceAtLeast(0))
            trackTitle = playlist.getOrNull(trackIndex)?.title ?: "Глава"
            positionMs = playbackPrefs.getInt("widget_position", 0).coerceAtLeast(0)
            durationMs = playbackPrefs.getInt("widget_duration", 0).coerceAtLeast(0)
        } catch (_: Exception) { playlist = emptyList(); trackIndex = -1 }
    }

    private fun persistPlaylist() {
        val array = JSONArray()
        playlist.forEach { array.put(JSONObject().put("t", it.title).put("s", it.src).put("d", it.durationMs)) }
        val cover = File(File(File(Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS), "AudioBooks"), safeFileName(bookTitle)), "cover.jpg")
        playbackPrefs.edit().putString("widget_playlist", array.toString())
            .putString("widget_source_type", sourceType).putString("widget_book", bookTitle)
            .putString("widget_cover_path", if (cover.exists()) cover.absolutePath else "")
            .putString("widget_cover_url", playbackPrefs.getString(bookCoverKey(bookTitle), "").orEmpty())
            .apply()
        metadataKey = ""
        coverBook = ""
        coverBitmap = null
    }

    private fun startTrack(index: Int, startPosition: Int, autoPlay: Boolean = true) {
        val item = playlist.getOrNull(index) ?: return
        if (sleepChapterTarget.isNotEmpty() && sleepChapterTarget != "$sourceType|$bookTitle|$index") {
            sleepChapterTarget = ""
        }
        releasePlayer()
        val token = ++generation
        resumeAfterFocus = false
        pausedAt = 0L
        playWhenReady = autoPlay
        trackIndex = index
        trackTitle = item.title.ifBlank { "Глава" }
        positionMs = startPosition.coerceAtLeast(0)
        durationMs = item.durationMs.coerceAtLeast(0)
        isPlaying = false
        isLoading = true
        errorMessage = ""
        appliedEq = null
        try {
            val player = MediaPlayer()
            mediaPlayer = player
            try { player.setWakeMode(this, android.os.PowerManager.PARTIAL_WAKE_LOCK) } catch (_: Exception) {}
            player.setAudioStreamType(AudioManager.STREAM_MUSIC)
            if (item.src.startsWith("content://")) player.setDataSource(this, android.net.Uri.parse(item.src))
            else player.setDataSource(item.src)
            player.setOnPreparedListener { prepared ->
                if (token != generation || prepared !== mediaPlayer || stopped) return@setOnPreparedListener
                isLoading = false
                durationMs = prepared.duration.coerceAtLeast(0)
                positionMs = positionMs.coerceIn(0, (durationMs - 1).coerceAtLeast(0))
                if (positionMs > 0) {
                    pendingSeek = positionMs
                    prepared.seekTo(positionMs)
                }
                applySettings()
                if (playWhenReady) resumePlayback() else publish()
                persistState()
            }
            player.setOnSeekCompleteListener {
                if (token == generation && it === mediaPlayer && !isLoading) {
                    pendingSeek = null
                    readPosition(); persistState(); publish()
                }
            }
            player.setOnCompletionListener { completed ->
                if (token == generation && completed === mediaPlayer && !stopped) completeTrack()
            }
            player.setOnErrorListener { failed, what, extra ->
                if (token == generation && failed === mediaPlayer && !stopped) {
                    failPlayback("Ошибка воспроизведения ($what / $extra)")
                }
                true
            }
            persistState()
            publish()
            player.prepareAsync()
        } catch (error: Exception) {
            failPlayback("Ошибка плеера: ${error.message ?: "неизвестная"}")
        }
    }

    @Suppress("DEPRECATION")
    private fun requestFocus(): Boolean {
        if (hasAudioFocus) return true
        hasAudioFocus = audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC,
            AudioManager.AUDIOFOCUS_GAIN) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        return hasAudioFocus
    }

    @Suppress("DEPRECATION")
    private fun abandonFocus() {
        audioManager.abandonAudioFocus(focusListener)
        hasAudioFocus = false
        duckVolume = 1f
    }

    private fun resumePlayback() {
        playWhenReady = true
        if (isLoading) { publish(); return }
        val player = mediaPlayer
        if (player == null) {
            if (playlist.isNotEmpty()) startTrack(trackIndex.coerceIn(0, playlist.lastIndex), positionMs)
            return
        }
        try {
            if (!requestFocus()) {
                playWhenReady = false
                publish()
                return
            }
            if (pausedAt > 0L && SystemClock.elapsedRealtime() - pausedAt >= 30_000L) {
                val rewind = playbackPrefs.getInt("rewind_after_pause_sec", 5).coerceIn(0, 60)
                positionMs = (positionMs - rewind * 1000).coerceAtLeast(0)
                pendingSeek = positionMs
                player.seekTo(positionMs)
            }
            pausedAt = 0L
            player.start()
            isPlaying = true
            applySettings()
            maybeScheduleTimer()
            updateVolume()
            persistState()
            publish()
        } catch (error: Exception) { failPlayback("Не удалось продолжить: ${error.message}") }
    }

    private fun pausePlayback(releaseFocus: Boolean = true) {
        playWhenReady = false
        try { if (!isLoading && mediaPlayer?.isPlaying == true) mediaPlayer?.pause() } catch (_: Exception) {}
        readPosition()
        if (isPlaying && pausedAt == 0L) pausedAt = SystemClock.elapsedRealtime()
        isPlaying = false
        if (releaseFocus) abandonFocus()
        persistState()
        publish()
    }

    private fun seekPlayback(requested: Long) {
        val maximum = if (durationMs > 0) durationMs else Int.MAX_VALUE
        positionMs = requested.coerceIn(0L, maximum.toLong()).toInt()
        try {
            if (!isLoading && mediaPlayer != null) {
                pendingSeek = positionMs
                mediaPlayer?.seekTo(positionMs)
            }
        } catch (_: Exception) { pendingSeek = null }
        persistState()
        publish()
    }

    private fun skip(delta: Int) {
        resumeAfterFocus = false
        if (playlist.isEmpty()) return
        readPosition()
        persistState()
        val current = trackIndex.coerceIn(0, playlist.lastIndex)
        if (delta < 0) startTrack(if (positionMs > 3000 || current == 0) current else current - 1, 0)
        else if (current < playlist.lastIndex) startTrack(current + 1, 0)
        else { setTimer(0, false); pausePlayback(); advanceQueue() }
    }

    private fun completeTrack() {
        isPlaying = false
        positionMs = durationMs
        persistState()
        if (sleepChapterTarget == chapterKey()) {
            setTimer(0, false)
            // Сохраняем следующую главу, но не запускаем её до нажатия Play.
            if (trackIndex < playlist.lastIndex) startTrack(trackIndex + 1, 0, autoPlay = false)
            else pausePlayback()
            Toast.makeText(this, "🌙 Таймер сна: глава завершена", Toast.LENGTH_LONG).show()
        } else if (trackIndex < playlist.lastIndex) {
            startTrack(trackIndex + 1, 0)
        } else {
            pausePlayback()
            advanceQueue()
        }
    }

    private fun advanceQueue() {
        val completedBook = bookTitle
        val token = generation
        playWhenReady = true
        isLoading = true
        publish()
        queueWorker.execute {
            val books = scanLibrary(this)
            handler.post {
                if (stopped || token != generation) return@post
                val queue = loadQueue(playbackPrefs).filter { it != completedBook }
                val nextBook = queue.asSequence().mapNotNull { title ->
                    books.firstOrNull { it.title == title && it.files.isNotEmpty() }
                }.firstOrNull()
                saveQueue(playbackPrefs, queue.filter { it != nextBook?.title })
                isLoading = false
                if (nextBook == null) { setTimer(0, false); publish(); return@post }
                bookTitle = nextBook.title
                sourceType = "local"
                playlist = nextBook.files.map { ServiceTrack(it.nameWithoutExtension, libraryTrackSource(it)) }
                val index = playbackPrefs.getInt(bookProgressTrackKey(bookTitle), 0)
                    .coerceIn(0, playlist.lastIndex)
                val position = playbackPrefs.getInt(bookProgressPositionKey(bookTitle), 0)
                persistPlaylist()
                addListeningHistory(playbackPrefs, bookTitle)
                startTrack(index, position, autoPlay = playWhenReady)
            }
        }
    }

    private fun readPosition() {
        if (isLoading || pendingSeek != null) return
        try { mediaPlayer?.let { positionMs = it.currentPosition; durationMs = it.duration } } catch (_: Exception) {}
    }

    private fun persistState() {
        if (trackIndex !in playlist.indices || bookTitle.isBlank()) return
        val lastPrefix = if (sourceType == "online") "online_last_" else "player_last_"
        playbackPrefs.edit().putString("widget_book", bookTitle).putString("widget_track", trackTitle)
            .putInt("widget_track_index", trackIndex).putInt("widget_position", positionMs)
            .putInt("widget_duration", durationMs).putString("widget_media_src", playlist[trackIndex].src)
            .putString(lastPrefix + "book", bookTitle).putInt(lastPrefix + "track", trackIndex)
            .putInt(lastPrefix + "position", positionMs)
            .putInt(bookProgressTrackKey(bookTitle), trackIndex)
            .putInt(bookProgressPositionKey(bookTitle), positionMs).apply()
        lastPersistAt = SystemClock.elapsedRealtime()
    }

    private fun applySettings() {
        playbackSpeed = playbackPrefs.getFloat("book_speed_" + safeFileName(bookTitle),
            playbackPrefs.getFloat("playback_speed", 1f)).let { if (it.isFinite()) it.coerceIn(0.5f, 3f) else 1f }
        val player = mediaPlayer
        if (player != null && !isLoading) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    // setPlaybackParams может запустить приостановленный MediaPlayer.
                    player.playbackParams = player.playbackParams.setSpeed(playbackSpeed)
                    if (!isPlaying) player.pause()
                } catch (_: Exception) {}
            }
            val settings = loadEqSettings(playbackPrefs, bookTitle)
            if (settings != appliedEq || audioFx.sessionId != player.audioSessionId) {
                eqAvailable = audioFx.attach(player.audioSessionId, settings)
                appliedEq = settings
            }
        }
        updateShakeListener()
    }

    private fun chapterKey() = "$sourceType|$bookTitle|$trackIndex"
    private fun timerActive() = sleepEndAt > 0L || sleepChapterTarget.isNotEmpty()

    private fun remainingSleepSeconds(): Int {
        if (sleepChapterTarget.isNotEmpty()) {
            return ((durationMs - positionMs).coerceAtLeast(0) / 1000f / playbackSpeed.coerceAtLeast(0.5f))
                .toInt().coerceAtLeast(1)
        }
        return if (sleepEndAt > 0L) Math.ceil((sleepEndAt - SystemClock.elapsedRealtime()) / 1000.0)
            .toInt().coerceAtLeast(0) else 0
    }

    private fun setTimer(seconds: Int, chapter: Boolean) {
        sleepChapterTarget = if (chapter && trackIndex in playlist.indices) chapterKey() else ""
        sleepEndAt = if (!chapter && seconds > 0) SystemClock.elapsedRealtime() + seconds.toLong() * 1000L else 0L
        if (!chapter && seconds > 60) playbackPrefs.edit().putInt("last_sleep_seconds", seconds).apply()
        updateVolume()
        updateShakeListener()
        publish()
    }

    private fun maybeScheduleTimer() {
        if (!timerActive() && playbackPrefs.getBoolean("sleep_sched_enabled", false) &&
            isHourInWindow(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY),
                playbackPrefs.getInt("sleep_sched_from", 22), playbackPrefs.getInt("sleep_sched_to", 6))) {
            setTimer(playbackPrefs.getInt("sleep_sched_minutes", 30).coerceIn(1, 180) * 60, false)
        }
    }

    private fun updateVolume() {
        val remaining = remainingSleepSeconds()
        val fade = if (sleepChapterTarget.isEmpty() && sleepEndAt > 0L && remaining <= 10)
            remaining / 10f else 1f
        try { mediaPlayer?.setVolume(fade * duckVolume, fade * duckVolume) } catch (_: Exception) {}
    }

    private fun updateShakeListener() {
        val wanted = timerActive() && isPlaying && playbackPrefs.getBoolean("sleep_shake", true)
        if (wanted == shakeRegistered) return
        if (wanted) {
            val sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (sensor != null) shakeRegistered = sensorManager.registerListener(shakeListener, sensor,
                SensorManager.SENSOR_DELAY_NORMAL)
        } else {
            sensorManager.unregisterListener(shakeListener)
            shakeRegistered = false
        }
    }

    private fun releasePlayer() {
        generation++
        pendingSeek = null
        try { mediaPlayer?.release() } catch (_: Exception) {}
        mediaPlayer = null
        isLoading = false
        isPlaying = false
        audioFx.release()
        appliedEq = null
    }

    private fun failPlayback(message: String) {
        readPosition()
        persistState()
        releasePlayer()
        abandonFocus()
        errorMessage = message
        publish()
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun stopPlayback() {
        readPosition()
        persistState()
        resumeAfterFocus = false
        releasePlayer()
        abandonFocus()
        sleepEndAt = 0L
        sleepChapterTarget = ""
        updateShakeListener()
        publish()
        stopped = true
        handler.removeCallbacks(tickRunnable)
        stopForeground(true)
        stopSelf()
    }

    private fun publish(refreshNotification: Boolean = true) {
        mutableState.value = ServicePlaybackState(bookTitle, sourceType, playlist, trackIndex,
            positionMs, durationMs, isPlaying, isLoading, mediaPlayer != null || isLoading,
            playbackSpeed, eqAvailable, remainingSleepSeconds(), sleepChapterTarget, errorMessage)
        if (refreshNotification && !stopped) {
            updateSessionState()
            try { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification()) }
            catch (_: Exception) {}
            lastNotificationAt = SystemClock.elapsedRealtime()
        }
    }

    private fun updateSessionState() {
        val playbackState = when {
            isLoading -> PlaybackState.STATE_BUFFERING
            isPlaying -> PlaybackState.STATE_PLAYING
            mediaPlayer != null -> PlaybackState.STATE_PAUSED
            else -> PlaybackState.STATE_STOPPED
        }
        val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
            PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_STOP or PlaybackState.ACTION_SEEK_TO
        mediaSession.setPlaybackState(PlaybackState.Builder().setActions(actions)
            .setState(playbackState, positionMs.toLong(), if (isPlaying) playbackSpeed else 0f).build())
        AudioBookWidget.updateAll(this, bookTitle, trackTitle, isPlaying, positionMs, durationMs)
        val cover = loadCoverCached()
        val key = "$bookTitle|$trackTitle|$durationMs|${cover != null}"
        if (key != metadataKey) {
            metadataKey = key
            val metadata = MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, trackTitle)
                .putString(MediaMetadata.METADATA_KEY_ALBUM, bookTitle)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, bookTitle)
                .putLong(MediaMetadata.METADATA_KEY_DURATION, durationMs.toLong())
            if (cover != null) metadata.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, cover)
            mediaSession.setMetadata(metadata.build())
        }
    }

    private fun loadCoverCached(): Bitmap? {
        if (coverBook == bookTitle && coverBitmap != null) {
            return coverBitmap
        }

        val file = findCover()

        val bitmap = try {
            if (file == null) {
                null
            } else {
                val bounds = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }

                BitmapFactory.decodeFile(file.absolutePath, bounds)

                var sample = 1

                while (
                    bounds.outWidth / sample > 1024 ||
                    bounds.outHeight / sample > 1024
                ) {
                    sample *= 2
                }

                BitmapFactory.decodeFile(
                    file.absolutePath,
                    BitmapFactory.Options().apply {
                        inSampleSize = sample
                    }
                )
            }
        } catch (_: Exception) {
            null
        }

        coverBook = bookTitle
        coverBitmap = bitmap

        return bitmap
    }

    @Suppress("DEPRECATION")
    private fun findCover(): File? {
        return try {
            val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val root = File(downloads, "AudioBooks")
            val direct = File(File(root, safeFileName(bookTitle)), "cover.jpg")

            if (direct.exists() && direct.length() > 0L) {
                direct
            } else {
                val wanted = safeFileName(bookTitle).lowercase()
                root.listFiles()
                    ?.asSequence()
                    ?.filter { it.isDirectory }
                    ?.map { File(it, "cover.jpg") }
                    ?.firstOrNull {
                        it.exists() &&
                        it.length() > 0L &&
                        (
                            safeFileName(it.parentFile?.name ?: "").lowercase() == wanted ||
                            wanted.contains(safeFileName(it.parentFile?.name ?: "").lowercase()) ||
                            safeFileName(it.parentFile?.name ?: "").lowercase().contains(wanted)
                        )
                    }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent {
        return PendingIntent.getService(
            this,
            requestCode,
            Intent(this, PlaybackService::class.java).apply { this.action = action },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            10,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val previous = Notification.Action.Builder(
            android.R.drawable.ic_media_previous,
            "Предыдущая",
            servicePendingIntent(ACTION_PREVIOUS, 11)
        ).build()

        val toggle = Notification.Action.Builder(
            if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
            if (isPlaying) "Пауза" else "Продолжить",
            servicePendingIntent(ACTION_TOGGLE, 12)
        ).build()

        val next = Notification.Action.Builder(
            android.R.drawable.ic_media_next,
            "Следующая",
            servicePendingIntent(ACTION_NEXT, 13)
        ).build()

        val stop = Notification.Action.Builder(
            android.R.drawable.ic_menu_close_clear_cancel,
            "Остановить",
            servicePendingIntent(ACTION_STOP, 14)
        ).build()

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(bookTitle)
            .setContentText(trackTitle)
            .setContentIntent(openApp)
            .setOnlyAlertOnce(true)
            .setOngoing(isPlaying)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(previous)
            .addAction(toggle)
            .addAction(next)
            .addAction(stop)
            .setStyle(
                Notification.MediaStyle()
                    .setMediaSession(mediaSession.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Воспроизведение аудиокниг",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Управление воспроизведением аудиокниг"
                setSound(null, null)
                enableVibration(false)
            }
            manager.createNotificationChannel(channel)
        }
    }


    override fun onDestroy() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
        readPosition()
        persistState()
        releasePlayer()
        abandonFocus()
        playbackPrefs.unregisterOnSharedPreferenceChangeListener(preferenceListener)
        try { unregisterReceiver(noisyReceiver) } catch (_: Exception) {}
        sensorManager.unregisterListener(shakeListener)
        queueWorker.shutdownNow()
        try { mediaSession.isActive = false; mediaSession.release() } catch (_: Exception) {}
        coverBitmap = null
        if (instance === this) {
            instance = null
            mutableState.value = mutableState.value.copy(
                isPlaying = false, isLoading = false, hasPlayer = false,
                sleepSeconds = 0, sleepChapterTarget = "")
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
